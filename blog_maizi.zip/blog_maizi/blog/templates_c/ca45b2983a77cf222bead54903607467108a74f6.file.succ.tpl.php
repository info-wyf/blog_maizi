<?php /* Smarty version Smarty-3.1.21-dev, created on 2015-04-06 11:56:22
         compiled from ".\templates\succ.tpl" */ ?>
<?php /*%%SmartyHeaderCode:19788552257016c48a7-10424932%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ca45b2983a77cf222bead54903607467108a74f6' => 
    array (
      0 => '.\\templates\\succ.tpl',
      1 => 1428314177,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '19788552257016c48a7-10424932',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_5522570172a1c3_65758564',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5522570172a1c3_65758564')) {function content_5522570172a1c3_65758564($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ('header.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>


<meta http-equiv="Refresh" content="3; url=http://localhost/blog/"/>

	<div>
		<div style="text-align:center">
			<h1>注册成功</h1>
			<p><a href="http://localhost/blog/">3秒后跳转,点击跳转...</a></p>
		</div>

	</div>

</div> 	
<?php echo $_smarty_tpl->getSubTemplate ('footer.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>
<?php }} ?>
