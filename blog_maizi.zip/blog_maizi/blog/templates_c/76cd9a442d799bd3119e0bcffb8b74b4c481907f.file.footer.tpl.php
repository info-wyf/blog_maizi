<?php /* Smarty version Smarty-3.1.21-dev, created on 2015-04-02 15:22:36
         compiled from ".\templates\footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:6551d429c02a9d4-01385773%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '76cd9a442d799bd3119e0bcffb8b74b4c481907f' => 
    array (
      0 => '.\\templates\\footer.tpl',
      1 => 1427980833,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '6551d429c02a9d4-01385773',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_551d429c02a9d4_00248376',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_551d429c02a9d4_00248376')) {function content_551d429c02a9d4_00248376($_smarty_tpl) {?></div> <!-- /main -->	
	
<!-- FOOTER -->
<div id="footer">

	<div class="main box">
		<p class="f-right t-right"> 联系我们 | 招聘信息 | 网站律师  使用须知</p>
		<p class="f-left">Copyright &copy;&nbsp;2015 <a href="http://www.maiziedu.com/">麦子学院</a></p>
	</div> 

</div> <!-- /footer -->
</body>
</html><?php }} ?>
