<?php
/* Smarty version 3.1.29, created on 2016-06-04 10:16:01
  from "D:\WWW\blog_maizi\blog\templates\footer.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_575239e1bf23d5_39495250',
  'file_dependency' => 
  array (
    '0cc0fa681bbfdda368ff01cec4a872fcc66d0a44' => 
    array (
      0 => 'D:\\WWW\\blog_maizi\\blog\\templates\\footer.tpl',
      1 => 1465006559,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_575239e1bf23d5_39495250 ($_smarty_tpl) {
?>
</div> <!-- /main -->	
	
<!-- FOOTER -->
<div id="footer">

	<div class="main box">	
                <p class="f-right t-right" > <a href="http://www.shu.edu.cn/Default.aspx?tabid=8558" >联系我们 </a> | 
                                            <a href="http://map.shu.edu.cn/" >学校地址 </a> | 
                                            <a href="http://www.lxyz.shu.edu.cn/" >两学一做 </a> | 
                                            <a href="http://www.dwgk.shu.edu.cn/" >党务公开 </a></p>
               	
                <p class="f-left">Copyright &copy;&nbsp;2016 <a href="http://www.shu.edu.cn/" >上海大学</a></p>             
	</div> 

</div> <!-- /footer -->
</body>
</html><?php }
}
