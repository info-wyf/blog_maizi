<?php
/* Smarty version 3.1.29, created on 2016-06-03 10:43:26
  from "D:\WWW\blog_maizi\blog\templates\succ.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_5750eece44aab5_94956788',
  'file_dependency' => 
  array (
    '7f684f9380df2c1360ec6dbc8e525d807919a02e' => 
    array (
      0 => 'D:\\WWW\\blog_maizi\\blog\\templates\\succ.tpl',
      1 => 1464920590,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_5750eece44aab5_94956788 ($_smarty_tpl) {
$_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>


<meta http-equiv="Refresh" content="3; url=http://localhost:8090/blog_maizi/blog/"/>

	<div>
		<div style="text-align:center">
			<h1>注册成功</h1>
			<p><a href="http://localhost:8090/blog_maizi/blog/">3秒后跳转,点击跳转...</a></p>
		</div>

	</div>

</div> 	
<?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
