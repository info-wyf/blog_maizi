<?php
/**
 * 
 * @authors wyf
 * @date    2016-06-04 09:50:22
 */

require_once 'ModelBase.class.php';

class LoginModel extends ModelBase {

    //执行逻辑
    public  function preform(){
    	
    }


	//检测参数
    public function checkparams(){

    }
}