<?php
echo 'hello word';